
import time
import json
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from datetime import datetime
import os

# Log dosyasının yolu
LOG_FILE = './logs/changes.json'  # Genel bir log yolu

class ChangeHandler(FileSystemEventHandler):
    def on_any_event(self, event):
        # Olay bilgilerini al
        event_info = {
            'event_type': event.event_type,
            'is_directory': event.is_directory,
            'path': event.src_path,
            'timestamp': datetime.now().isoformat()
        }

        # Log dosyasına yaz
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, 'a') as f:
            f.write(json.dumps(event_info) + '\n')

if __name__ == "__main__":
    # İzlenecek dizin
    path = './test'  # Genel bir test yolu

    # Log dosyasının var olup olmadığını kontrol et, yoksa oluştur
    if not os.path.exists(LOG_FILE):
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, 'w') as f:
            json.dump([], f)

    event_handler = ChangeHandler()
    observer = Observer()
    observer.schedule(event_handler, path, recursive=True)

    print(f"Monitoring started on: {path}")
    try:
        observer.start()
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
